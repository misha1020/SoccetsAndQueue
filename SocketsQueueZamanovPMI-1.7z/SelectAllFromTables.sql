select * from dbo.tStudent
select * from dbo.tSpecialty
select * from dbo.tFaculty
select * from dbo.tUniversity
select * from dbo.tCity