DELETE dbo.tStudent
DELETE dbo.tSpecialty
DELETE dbo.tFaculty
DELETE dbo.tUniversity
DELETE dbo.tCity